branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
fix(branch_data)
attach(branch_data)


boxplot(Sales_X1,main="Box plot for Sales ",outline=TRUE,outpch=8,horizontal = TRUE)

Summary(Advertising_X2)
IQR(Advertising_X2)
find_outliers<- function(data_vector){
  q1<-quantile(data_vector)[2]
  q3<-quantile(data_vector)[4]
  
   iqr <- q3 - q1
  
 upper_bound <- q3 + 1.5*iqr
 lower_bound <- q1- 1.5*iqr

 print(paste("Lower bound -",lower_bound))
 print(paste("Upeer bound -",upper_bound))

 outliers<-sort(data_vector[data_vector < lower_bound | data_vector > upper_bound])

 if(length(outliers) == 0) {
    print("no outliers")
 }else {
   print(paste("outliers:",paste(outliers,collapse - ", ")))
  }
 }

find_outliers(Years_X3)